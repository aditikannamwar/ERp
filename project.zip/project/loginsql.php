<?php
//ERROR_REPORTING(0);
    
	
	$dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
    // die('Could not connect: ' . mysqli_error());
   }
   else
   {
   //echo 'Connected successfully';
   }
    include ('session.php');
         $username=$_POST['username'];
         $password=$_POST['password'];
         $sql="SELECT * from users where username='$username' and password='$password'";
		echo $sql;
	   $result = $conn->query($sql);

                    $row =$result->fetch_assoc();
                    session_start();
					
                    $_SESSION['uid']=$username;
                    $_SESSION['employee_id']=$row['employee_id'];
                    if($row['type']=='admin')
                    {
						
                      echo "<script>window.document.location.href='/admin/admin.php'</script>";
                    }
                    elseif ($row['type']=='manager') { 

                      echo "<script>window.document.location.href='/manager/manager.php'</script>";
                    }
                     elseif ($row['type']=='employee') 
                     {
               
                        echo "<script>window.document.location.href='/employee/empl.php'</script>";
                    }
                
        
       
       {
            echo"<script>alert('Invalid Credentials...')</script>";
                     header('Refresh:0.1;URL=login.php');
       }  
   
?>