<?php
error_reporting(0);
require_once('connect.php');


if(isset($_POST['submit']))
{
$eid =$_POST['employee_id'];
$sal =$_POST['sal_amt'];
$sdate =$_POST['sdate'];
$edate =$_POST['edate'];
$bonus =$_POST['bonus'];
$com =$_POST['com'];
$con =$_POST['con'];
$med =$_POST['med'];
    
     $total=$sal+$sal/2+$bonus+$com+$con+$med;
    $house=$sal/2;
$querry="INSERT INTO salary (eid,basic_sal,sdate,edate,bonus,comm,con,med,house,total) 
VALUES('".$eid."','".$sal."','".$sdate."','".$edate."','".$bonus."','".$com."','".$con."','".$med."','$house','$total')";
    
$success = $conn->query($querry); 
    
$qr="select * from salary_gross where eid = $eid";
$result=$conn->query($qr);
if($result->num_rows>0)
{
    

        $row=$result->fetch_assoc();
    
        $actual_salary=$row['salary']+$sal;
        $actual_house=$actual_salary/2;
        $actual_bonus=$row['bonus']+$bonus;
        $actual_com=$row['com']+$com;
        $actual_con=$row['con']+$con;
        $actual_med=$row['med']+$med;
        $total=$sal+$sal/2+$bonus+$com+$con+$med;
        $actual_total=$row['total']+$total;
    $sql1="UPDATE salary_gross SET salary='$actual_salary', house='$actual_house',bonus='$actual_bonus',com='$actual_com',con='$actual_con',med='$actual_med',total='$actual_total' where eid='$eid'";
    
    $result2=$conn->query($sql1); 
    if(!$result2)
        echo"update query not working.";
}
else
{
    
    $house=$sal/2;
    $total=$sal+$house+$bonus+$com+$con+$med;
    $sql2="insert into  salary_gross values($eid,'$sal','$house','$bonus','$com','$con','$med','$total')";
    $result1=$conn->query($sql2); 
}   
    if($success)
    {
        print '<script type="text/javascript">';
        print 'alert("The data is inserted...")';
        print '</script>';
        
    }
    
    if($success)
        header('location:salary.php');
}
else
    echo " ";
$conn->close();
    
    
?>


