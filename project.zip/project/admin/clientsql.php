<?php
//error_reporting(0);
include('connect.php');
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
$cid =$_POST['client_id'];
$cname =$_POST['cname'];
$web =$_POST['web'];
$pemail =$_POST['pemail'];
$tele_no=$_POST['tele_no'];
$address =$_POST['address'];
$city=$_POST['city'];
$state=$_POST['state'];
$country=$_POST['country'];
$zip=$_POST['zip'];



$querry="INSERT INTO client (client_id,cname,web,pmail,tele_no,address,city,state,country,zip) 
VALUES ('".$cid."','".$cname."','".$web."','".$pemail."','".$tele_no."','".$address."','".$city."','".$state."','".$country."','".$zip."')";
echo $querry;

$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
$conn->close();
?>
