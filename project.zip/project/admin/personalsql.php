<?php
error_reporting(0);
require_once("session.php");
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }

   
 
$fthname =$_POST['fthname'];
$mthname =$_POST['mthname'];
$gender=$_POST['gender'];
$odob=$_POST['odob'];
$adob=$_POST['adob'];
$tele_no=$_POST['tele_no'];
$pemail=$_POST['pemail'];
$bg=$_POST['bg'];

$var = $_SESSION['employee_id'];
$search=$var;
$querry="INSERT INTO personal(employee_id,fthname,mthname,gender,odob,adob,tele_no,pemail,bg) 
VALUES('".$var."','".$fthname."','".$mthname."','".$gender."','".$odob."','".$adob."','".$tele_no."','".$pemail."','".$bg."')";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}

header('location:academic.php');

$conn->close();
?>


