<?php
error_reporting(0);
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }

$emp_id =$_SESSION['emp_id'];
$comname =$_POST['comname'];
$jt =$_POST['jt'];
$fdate =$_POST['fdate'];
$tdate=$_POST['tdate'];
$jd=$_POST['jd'];



$querry="UPDATE workexp  
SET comname='".$comname."',jt='".$jt."',fdate='".$fdate."',tdate='".$tdate."',jd='".$jd."'
WHERE emp_id='".$emp_id."'";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


