<?php
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }

$emp_id =$_SESSION['emp_id'];
$fname =$_POST['fname'];
$fthname =$_POST['fthname'];
$mthname =$_POST['mthname'];
$gender=$_POST['gender'];
$odob=$_POST['odob'];
$adob=$_POST['adob'];
$tele_no=$_POST['tele_no'];
$pemail=$_POST['pemail'];
$bg=$_POST['bg'];


$querry="UPDATE  personal  
SET fname='".$fname."',fthname='".$fthname."',mthname='".$mthname."',gender='".$gender."',odob='".$odob."',adob='".$adob."',tele_no='".$tele_no."',pemail='".$pemail."',bg='".$bg."'
WHERE emp_id='".$emp_id."'";
echo $querry
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


