<?php
error_reporting(0);
require_once("session.php");
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }

   
$name =$_POST['name'];   
$sname =$_POST['sname'];
$Edu_insti =$_POST['Edu_insti'];
$field =$_POST['field'];
$doc=$_POST['doc'];
$domain=$_POST['domain'];
$addnote=$_POST['addnote'];

$var = $_SESSION['employee_id'];
$search=$var;
$querry="INSERT INTO academic (employee_id,name,sname,Edu_insti,field,doc,domain,addnote) 
VALUES('".$var."','".$name."','".$sname."','".$Edu_insti."','".$field."','".$doc."','".$domain."','".$addnote."')";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}

header('location:workexp.php');
$conn->close();
?>


