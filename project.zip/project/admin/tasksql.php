<?php
error_reporting(0);
require_once("session.php");
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
   
 $eid =$_SESSION['emp_id'];
$milename =$_POST['milename'];
$tt =$_POST['tt'];
$req=$_POST['req'];
$tdes=$_POST['tdes'];
$ddate=$_POST['ddate'];
$status=$_POST['status'];


$querry="INSERT INTO addtask(e_id,mile,tt,req,tdes,ddate,status) 
VALUES('".$eid."','".$milename."','".$tt."','".$req."','".$tdes."','".$ddate."','".$status."')";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:task_front.php');
$conn->close();
?>


