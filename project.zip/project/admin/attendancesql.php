<?php
error_reporting(0);
require_once('connect.php');
$eid =$_POST['eid'];
$tdate =$_POST['tdate'];
$fcheck =$_POST['fcheck'];
$lcheck=$_POST['lcheck'];
$tim=$_POST['tim'];
$stat=$_POST['stat'];
$remark=$_POST['remark'];

	$querry="INSERT INTO attendance (eid,tdate,firstcheck,lastcheck,status,remark) 
VALUES('".$eid."',CURRENT_DATE,'".$fcheck."','".$lcheck."','".$stat."','".$remark."',)";
echo $querry;

$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


