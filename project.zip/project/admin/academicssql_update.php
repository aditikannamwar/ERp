<?php
error_reporting(0);
require_once("session.php");
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
 
$name =$_POST['name'];   
$sname =$_POST['sname'];
$Edu_insti =$_POST['Edu_insti'];
$field =$_POST['field'];
$doc=$_POST['doc'];
$domain=$_POST['domain'];
$addnote=$_POST['addnote'];

$var = $_SESSION['employee_id'];
$search=$var;
$querry="UPDATE academic 
SET name='".$name."',sname='".$sname."',Edu_insti='".$Edu_insti."',field='".$field."',doc='".$doc."',domain='".$domain."',addnote='".$addnote."'
where emp_id='".$employee_id."'";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


