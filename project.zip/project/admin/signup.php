<!-- === BEGIN HEADER === -->


<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <!-- Title -->
    <title>OCEANERGY LOGIN</title>
    <!-- Meta -->
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- Favicon -->
    <link href="favicon.ico" rel="shortcut icon">
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/animate.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/nexus.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/custom.css" rel="stylesheet">
    <!-- Google Fonts-->
    <link href="http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=PT+Sans" type="text/css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Roboto:400,300" rel="stylesheet" type="text/css">
    <style>
        /* Full-width input fields */

        input[type=text],
        input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        /* Set a style for all buttons */

        button {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        /* Extra styles for the cancel button */

        .cancelbtn {
            padding: 14px 20px;
            background-color: #f44336;
        }

        /* Float cancel and signup buttons and add an equal width */

        .cancelbtn,
        .signupbtn {
            float: left;
            width: 50%;
        }

        /* Add padding to container elements */

        .container {
            padding: 16px;
        }

        /* Clear floats */

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        /* Change styles for cancel button and signup button on extra small screens */

        @media screen and (max-width: 300px) {
            .cancelbtn,
            .signupbtn {
                width: 100%;
            }
        }

    </style>
</head>

<body>
    <div id="body-bg">
        <ul class="social-icons pull-right hidden-xs">

            <li class="social-twitter">
                <a href="#" target="_blank" title="Twitter"></a>
            </li>
            <li class="social-facebook">
                <a href="#" target="_blank" title="Facebook"></a>
            </li>
            <li class="social-googleplus">
                <a href="#" target="_blank" title="GooglePlus"></a>
            </li>
        </ul>
        <div id="pre-header" class="container" style="height: 40px">
            <!-- Spacing above header -->
        </div>
        <div id="header">
            <div class="container">
                <div class="row">
                    <!-- Logo -->
                    <div class="logo">

                        <a href="http://www.oceanergy.in/" title="">
                                <img src="assets/Oceanergy_Logo_PNG_HighRes.png" alt="Logo" width="69px" height="69px" align="left" style="margin-top:30px ;margin-right:10px"/>
                                
								 <img src="assets/Oceanergy_Name_PNG_HighRes.png" alt="Logo" width="169px" height="30px" align="left" style="margin-top:50px ;margin-right:120px" />
                            </a>
                    </div>
                    <!-- End Logo -->
                </div>
            </div>
        </div>

        <div id="post_header" class="container" style="height: 40px">
            <!-- Spacing below header -->
        </div>
        <div id="content-top-border" class="container">
        </div>
        <!-- === END HEADER === -->
        <!-- === BEGIN CONTENT === -->
        <div id="content">
            <div class="container background-white">
                <div class="container">
                    <div class="row margin-vert-30">
                        <div class="article">
                            <div class="container">
                                <form action="signupsql.php" method="post" style="border:1px solid #ccc">
                                    <style>
                                        form {
                                            background-color: #91b1b4;
                                        }

                                    </style>
                                    <div class="container">
                                        <div class="form-group">
                                            <label for="sel1">Select Type:</label>
                                            <select name="type" class="form-control" id="sel1">
                                                <option>admin</option>
                                                <option>employee</option>
                                                <option>manager</option>
                                              </select>
                                        </div>
                                        <label><b>Employee ID:</b></label>
                                        <input type="text" placeholder="Enter Employee ID" name="emp_id" required>

                                        <label><b>Name:</b></label>
                                        <input type="text" placeholder="Enter Name" name="name" required>

                                        <label><b>Email:</b></label>
                                        <input type="text" placeholder="Enter Email" name="email" required>

                                        <label><b>Phone Number:</b></label>
                                        <input type="text" placeholder="Enter Phone Number" name="phone" required>

                                        <label><b>Username:</b></label>
                                        <input type="text" placeholder="Enter Username" name="username" required>

                                        <label><b>Password:</b></label>
                                        <input type="password" placeholder="Enter Password" name="psw" required>

                                        <label><b>Confirm Password:</b></label>
                                        <input type="password" placeholder="Repeat Password" name="pswrepeat" required>


                                        <div class="clearfix">
                                            <button type="button" class="cancelbtn"><a href="login.php">Cancel</a></button>
                                            <button type="submit" name="submit" class="signupbtn" >Sign Up</button>
                                        </div>
                                        
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- === END CONTENT === -->
        <!-- === BEGIN FOOTER === -->
        <div id="content-bottom-border" class="container">
        </div>
        <div id="base">
            <div class="container padding-vert-30 margin-top-60">
                <div class="row" style="align:center">
                    <!-- Contact Details -->
                    <div class="col-md-4 margin-bottom-20">
                        <h3 class="margin-bottom-10">Contact Details</h3>
                        <p>
                            <span class="fa-phone">Telephone:</span>+91 7506067024 , 0222 5170789
                            <br>
                            <span class="fa-envelope">Email:</span>
                            <a href="mailto:admin@oceanergy.in">admin@oceanergy.in</a>
                            <br>
                            <span class="fa-link">Website:</span>
                            <a href="http://www.oceanergy.in">http://www.oceanergy.in</a>
                        </p>
                        <p>C-1404, KAILASH BUSINESS PARK,
                            <br>HIRANADANI LINK ROAD,
                            <br>VIKHROLI (WEST), MAHARASHTRA - 400079
                        </p>
                    </div>
                    <!-- End Contact Details -->


                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- Footer Menu -->
        <div id="footer">
            <div class="container">
                <div class="row">
                    <div id="footermenu" class="col-md-8">

                    </div>
                    <div id="copyright" class="col-md-4">

                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Menu -->
        <!-- JS -->
        <script type="text/javascript" src="assets/js/jquery.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="assets/js/scripts.js"></script>
        <!-- Isotope - Portfolio Sorting -->
        <script type="text/javascript" src="assets/js/jquery.isotope.js" type="text/javascript"></script>
        <!-- Mobile Menu - Slicknav -->
        <script type="text/javascript" src="assets/js/jquery.slicknav.js" type="text/javascript"></script>
        <!-- Animate on Scroll-->
        <script type="text/javascript" src="assets/js/jquery.visible.js" charset="utf-8"></script>
        <!-- Sticky Div -->
        <script type="text/javascript" src="assets/js/jquery.sticky.js" charset="utf-8"></script>
        <!-- Slimbox2-->
        <script type="text/javascript" src="assets/js/slimbox2.js" charset="utf-8"></script>
        <!-- Modernizr -->
        <script src="assets/js/modernizr.custom.js" type="text/javascript"></script>
        <!-- End JS -->
</body>

</html>



<!-- === END FOOTER === -->+
