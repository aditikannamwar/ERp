<?php
error_reporting(0);
require_once("session.php");
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
   
 
$comname =$_POST['comname'];
$jt =$_POST['jt'];
$fdate =$_POST['fdate'];
$tdate=$_POST['tdate'];
$jd=$_POST['jd'];

$var = $_SESSION['employee_id'];
$search=$var;

$querry="INSERT INTO workexp (employee_id,comname,jt,fdate,tdate,jd) 
VALUES('".$var."','".$comname."','".$jt."','".$fdate."','".$tdate."','".$jd."')";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}

header('location:admin.php');
$conn->close();
?>


