<?php 
	session_start();
    session_destroy();
	echo"<script>alert('You have successfully logout.')</script>";
    header('Refresh:0.1;URL=login.php');
?>
