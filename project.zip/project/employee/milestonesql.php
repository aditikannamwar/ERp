<?php
error_reporting(0);
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
   
$pid =$_POST['pid'];
$title =$_POST['title'];
$des =$_POST['des'];
$sdate=$_POST['sdate'];
$edate=$_POST['edate'];
$checkbox=$_POST['checkbox'];



$querry="INSERT INTO milestone(project_id,title,des,sdate,edate,checkbox) 
VALUES('".$pid."','".$title."','".$des."','".$sdate."','".$edate."','".$checkbox."')";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:empl.php');
$conn->close();
?>


