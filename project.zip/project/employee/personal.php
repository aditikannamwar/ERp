<!-- === BEGIN HEADER === -->
<?php 
require_once("session.php");
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <head>
        <!-- Title -->
        <title>PERSONAL DETAILS</title>
        <!-- Meta -->
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <!-- Favicon -->
        <link href="favicon.ico" rel="shortcut icon">
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.css" rel="stylesheet">
        <!-- Template CSS -->
        <link rel="stylesheet" href="assets/css/animate.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/nexus.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/responsive.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/custom.css" rel="stylesheet">
        <!-- Google Fonts-->
        <link href="http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300" rel="stylesheet" type="text/css">
        <link href="http://fonts.googleapis.com/css?family=PT+Sans" type="text/css" rel="stylesheet">
        <link href="http://fonts.googleapis.com/css?family=Roboto:400,300" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div id="body-bg">
            
            <div id="pre-header" class="container" style="height: 40px">
                <!-- Spacing above header -->
            </div>
            <div id="header">
                <div class="container">
                    <div class="row">
                        <!-- Logo -->
                        <div class="logo">
						
                            <a href="http://www.oceanergy.in/" title="">
                                <img src="assets/Oceanergy_Logo_PNG_HighRes.png" alt="Logo" width="69px" height="69px" align="left" style="margin-top:30px ;margin-right:10px"/>
								 <img src="assets/Oceanergy_Name_PNG_HighRes.png" alt="Logo" width="169px" height="30px" align="left" style="margin-top:50px ;margin-right:120px"/>
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>
                </div>
            </div>
                  
       <!---Top nav-->
        <div id="hornav" class="container no-padding">
            <div class="row">
                <div class="col-md-12 no-padding">
                    <div class="text-center visible-lg">
                        <ul id="hornavmenu" class="nav navbar-nav">
                            <li>
                                <a href="empl.php" class="fa-home">Home</a>
                            </li>
                            <li>
                                <span class="fa-gears">Profile</span>
                                <ul>
								
                                    <li>
                                        <a href="front.php">Employee Details</a>
                                    </li>

                                    <li>
                                        <a href="emp.php">Employee</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="emp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="emp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="personal.php">Personal</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                           <li role="presentation"><a role="menuitem" tabindex="-1" href="personal.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="personal_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="academic.php">Academic</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="academic.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="academic_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a>Work Experience</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>

                                </ul>
                            </li>
                            
                            <li>
                                <span class="fa-copy">Leaves </span>
                                <ul>
                                    <li>
                                        <a href="leave_man.php">Add Leaves</a>
                                    </li>
                                    <li>
                                        <a href="leaveseek_front.php">My leaves</a>
                                    </li>
                                  

                                </ul>
                            </li>
							
							 <li>
                                <span class="fa-copy">Projects</span>
                                <ul>
                                     
                                    <li>
                                        <a href="project_front.php">View Project</a>
                                    </li>
                                    <li>
                                        <a href="miles_front.php">View Milestones</a>
                                    </li>
									<ul>
									<li>
									
                                        <a href="task.php">Add Tasks</a>
                                    </li> 
									<li>
									
                                        <a href="task_front.php">View Tasks</a>
                                    </li>
									</ul>
                                </ul>
                            </li>

					 
                            <li>
                                <a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> 
                                LOG OUT</a>

                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

		<!--- End Top nav-->
            <div id="post_header" class="container" style="height: 40px">
                <!-- Spacing below header -->
            </div>
            <div id="content-top-border" class="container">
            </div>
            <!-- === END HEADER === -->
            <!-- === BEGIN CONTENT === -->
            <div id="content">
                <div class="container background-white">
                    <div class="container">
                        <div class="row margin-vert-30">
                            <!-- Login Box -->
          
	
	<div class="article">
	<form onsubmit="return myfuction(telephone_no)" action="personalsql.php" method="post">
	<fieldset>
		<table  align="center">
			<tbody>
				<tr>
					<td align="left" colspan="2">
					<br>
					<div class="personal">
					<legend><p >Personal Details</p></legend>
					</div>
					</td>
				</tr>
				
				 
				
				
				

				<tr>
					<td align="left" colspan="1">
					<br>
					<label for id="fname">Fathers Name:</label><br>
					<input type="text" id="fname" size="30" maxlength="100" onclick="validate()" name="fthname" required name="fthname">
					</td>
				</tr>

				<tr>
				<td align="left" colspan="1">
					<br>
					<label for id="fname">Mothers name:</label><br>
					<input type="text" id="fname" size="30" maxlength="100" onclick="validate()" name="mthname" required name="mthname">
					</td>
				</tr>

				
				<tr>
				 <td align="left">  
				 <br>				 
				       <label for id="gender">*Gender</label><br>
   					   <input type="radio" name="gender" value="male" checked> Male<br>
						<input type="radio" name="gender" value="female"> Female<br>
						<input type="radio" name="gender" value="other"> Other<br>
					</td>	
				</tr>	

				<tr>	
					<td align="left">
					<br>
					<label for id="date">*Official.Date-Of-Birth:</label><br>
					<input type="date" name="odob" size="30"><br>
					</td>
				</tr>

				<tr>	
					<td align="left">
					<br>
					<label for id="date">*Actual Date-Of-Birth:</label><br>
					<input type="date" name="adob" size="30"><br>
					</td>
				</tr>


				 
				<tr>
					<td align="left">
					<br>
					<label for id="teleno">*Emergency Contact No:</label><br>
					<input type="tel" pattern="[789][0-9]{9}" id="teleno" size="30" maxlength="100" name="tele_no" required name="tele_no">
					
					</td>


					<tr>
					<td align="left" colspan="1">
					<label for id="form_email">*Personal Email Id:</label><br>
					<input type="email" id="form_email" size="30" maxlength="100"  onclick="validateForm()" name="pemail" required name="pemail">
			
					<div style="display:none">
					<label for id="email_verify">E-mail (verify()</label><br>
					<input type="text" id="email_verify" name="verify" size="30" maxlength="100" style="background-color:lightblue">
					</div>
			
					</td>
					<script>
					function validateForm() {
					var x = document.forms["form_email"]["form_email"].value;
					var atpos = x.indexOf("@");
    					var dotpos = x.lastIndexOf(".");
    					if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        				alert("Not a valid e-mail address");
        				return false;
    					}
					}
					</script>

				</tr>
					<tr>
					<td align="left">
					<label for id="bloodgroup">*Blood Group:</label><br>
					<input type="varchar" id="bloodgroup" size="20" maxlenght="20" name="bg" required name="bg">
					</tr>
			</tbody>
		</table>
		
		
		<table  align="center" >
			<tbody>
				<tr>
					<td  colspan="1">
					<div style="text-align:right">
					<a class="linnk" onclick="go-forward();" href="academic.html">
					<input type="Submit" value="Submit">
					</a>
					</div>
					</td>
					<td colspan="1">
					<a href="previous.html"><input type="Submit" value="Reset"></a>
					<br>
					</td>
				</tr>	
			</tbody>
		</table>
		</fieldset>
	</form>
                            <!-- End Login Box -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- === END CONTENT === -->
            <!-- === BEGIN FOOTER === -->
            <div id="content-bottom-border" class="container">
            </div>
            <div id="base">
                <div class="container padding-vert-30 margin-top-60">
                    <div class="row" style="align:center">
                        <!-- Contact Details -->
                        <div class="col-md-4 margin-bottom-20">
                            <h3 class="margin-bottom-10">Contact Details</h3>
                            <p>
                                <span class="fa-phone">Telephone:</span>+91 7506067024 , 0222 5170789
                                <br>
                                <span class="fa-envelope">Email:</span>
                                <a href="mailto:admin@oceanergy.in">admin@oceanergy.in</a>
                                <br>
                                <span class="fa-link">Website:</span>
                                <a href="http://www.oceanergy.in">http://www.oceanergy.in</a>
                            </p>
                            <p>C-1404, KAILASH BUSINESS PARK,
							<br>HIRANADANI LINK ROAD,
							<br>VIKHROLI (WEST), MAHARASHTRA - 400079
                             </p>
                        </div>
                        <!-- End Contact Details -->

                        
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- Footer Menu -->
            <div id="footer">
                <div class="container">
                    <div class="row">
                        <div id="footermenu" class="col-md-8">
                           
                        </div>
                        <div id="copyright" class="col-md-4">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer Menu -->
            <!-- JS -->
            <script type="text/javascript" src="assets/js/jquery.min.js" type="text/javascript"></script>
            <script type="text/javascript" src="assets/js/bootstrap.min.js" type="text/javascript"></script>
            <script type="text/javascript" src="assets/js/scripts.js"></script>
            <!-- Isotope - Portfolio Sorting -->
            <script type="text/javascript" src="assets/js/jquery.isotope.js" type="text/javascript"></script>
            <!-- Mobile Menu - Slicknav -->
            <script type="text/javascript" src="assets/js/jquery.slicknav.js" type="text/javascript"></script>
            <!-- Animate on Scroll-->
            <script type="text/javascript" src="assets/js/jquery.visible.js" charset="utf-8"></script>
            <!-- Sticky Div -->
            <script type="text/javascript" src="assets/js/jquery.sticky.js" charset="utf-8"></script>
            <!-- Slimbox2-->
            <script type="text/javascript" src="assets/js/slimbox2.js" charset="utf-8"></script>
            <!-- Modernizr -->
            <script src="assets/js/modernizr.custom.js" type="text/javascript"></script>
            <!-- End JS -->
    </body>
</html>
<!-- === END FOOTER === -->