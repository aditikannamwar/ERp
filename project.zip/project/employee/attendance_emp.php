<!-- === BEGIN HEADER === -->

<?php
require_once('session.php');
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <!-- Title -->
    <title>OCEANERGY LOGIN</title>
    <!-- Meta -->
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- Favicon -->
    <link href="favicon.ico" rel="shortcut icon">
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/animate.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/nexus.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/custom.css" rel="stylesheet">
    <!-- Google Fonts-->
    <link href="http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=PT+Sans" type="text/css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Roboto:400,300" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="body-bg">
        <ul class="social-icons pull-right hidden-xs">

            <li class="social-twitter">
                <a href="#" target="_blank" title="Twitter"></a>
            </li>
            <li class="social-facebook">
                <a href="#" target="_blank" title="Facebook"></a>
            </li>
            <li class="social-googleplus">
                <a href="#" target="_blank" title="GooglePlus"></a>
            </li>
        </ul>
        <div id="pre-header" class="container" style="height: 40px">
            <!-- Spacing above header -->
        </div>
        <div id="header">
            <div class="container">
                <div class="row">
                    <!-- Logo -->
                    <div class="logo">

                        <a href="http://www.oceanergy.in/" title="">
                                <img src="assets/Oceanergy_Logo_PNG_HighRes.png" alt="Logo" width="69px" height="69px" align="left" style="margin-top:30px ;margin-right:10px"/>
                                
								 <img src="assets/Oceanergy_Name_PNG_HighRes.png" alt="Logo" width="169px" height="30px" align="left" style="margin-top:50px ;margin-right:120px" />
                            </a>
                    </div>
                    <!-- End Logo -->
                </div>
            </div>
        </div>
        <!---Top nav-->
        <div id="hornav" class="container no-padding">
            <div class="row">
                <div class="col-md-12 no-padding">
                    <div class="text-center visible-lg">
                        <ul id="hornavmenu" class="nav navbar-nav">
                            <li>
                                <a href="empl.php" class="fa-home">Home</a>
                            </li>
                            <li>
                                <span class="fa-gears">Profile</span>
                                <ul>
								
                                    <li>
                                        <a href="front.php">Employee Details</a>
                                    </li>

                                    <li>
                                        <a href="emp.php">Employee</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="emp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="emp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="personal.php">Personal</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                           <li role="presentation"><a role="menuitem" tabindex="-1" href="personal.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="personal_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="academic.php">Academic</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="academic.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="academic_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a>Work Experience</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>

                                </ul>
                            </li>
                            
                            <li>
                                <span class="fa-copy">Leaves </span>
                                <ul>
                                    <li>
                                        <a href="leave_man.php">Add Leaves</a>
                                    </li>
                                    <li>
                                        <a href="leaveseek_front.php">My leaves</a>
                                    </li>
                                  

                                </ul>
                            </li>
							
							 <li>
                                <span class="fa-copy">Projects</span>
                                <ul>
                                     
                                    <li>
                                        <a href="project_front.php">View Project</a>
                                    </li>
                                    <li>
                                        <a href="miles_front.php">View Milestones</a>
                                    </li>
									<ul>
									<li>
									
                                        <a href="task.php">Add Tasks</a>
                                    </li> 
									<li>
									
                                        <a href="task_front.php">View Tasks</a>
                                    </li>
									</ul>
                                </ul>
                            </li>

					 
                            <li>
                                <a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> 
                                LOG OUT</a>

                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

		<!--- End Top nav-->
        <div id="post_header" class="container" style="height: 40px">
            <!-- Spacing below header -->
        </div>
        <div id="content-top-border" class="container">
        </div>
        <!-- === END HEADER === -->
        <!-- === BEGIN CONTENT === -->
        <div id="content">
            <div class="container background-white">
                <div class="container">
                    <div class="row margin-vert-40">
                        <div class="article">
                            <div class="container">
                                <form action="#" method="post">
                                    <label>From Date:</label>
                                    <input type="date" name="fdate">

                                    <label>To Date:</label>
                                    <input type="date" name="todate">



                                    <input type="Submit" name="submit" value="submit">
                                    <br><br>
                                    <?php
									error_reporting(0);
									//require_once('session.php');
                                        require_once("connect.php");
										
					                   $employee_id=$_SESSION['employee_id'];
										$fdate=$_POST['fdate'];
										$todate=$_POST['todate'];
                                        $sql=" SELECT eid,tdate,status from attendance where tdate between '$fdate' and '$todate' where employee_id=$employee_id";
                                        $result = $conn->query($sql);
                                         
                                        if($result->num_rows > 0)
                                        {
											echo"<label><h3><b>Attendance :</b></h3></label>";
                                            echo'<table class="table table-bordered" align="left">
                                                    <thead>
													
                                                      <tr>
													  
													  <th>Employee_ID</th>
                                                      <th>Date</th>
                                                        <th>Status</th>
                                    
                                                      </tr>
                                                    </thead>
                                                ';
                                                while($row = mysqli_fetch_assoc($result))
                                                {

                                                    echo '</tr>';
                                           
                                                    echo'<tbody';
                                                    echo'<tr>';
                                                    echo'<td>'.$row["eid"].'</td>';
                                                    echo'<td>'.$row["tdate"].'</td>';
                                                    echo'<td>'.$row["status"].'</td>';   
                                                    echo'</tr>';
                                              }  
                                            echo'</tbody>';
                                            echo'</table>';
                                            

                                      }
                                    else{
                                        echo "No results Found ";
                                    }
										
									
									
								
                                  ?>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- === END CONTENT === -->
        <!-- === BEGIN FOOTER === -->
        <div id="content-bottom-border" class="container">
        </div>
        <div id="base">
            <div class="container padding-vert-30 margin-top-60">
                <div class="row" style="align:center">
                    <!-- Contact Details -->
                    <div class="col-md-4 margin-bottom-20">
                        <h3 class="margin-bottom-10">Contact Details</h3>
                        <p>
                            <span class="fa-phone">Telephone:</span>+91 7506067024 , 0222 5170789
                            <br>
                            <span class="fa-envelope">Email:</span>
                            <a href="mailto:admin@oceanergy.in">admin@oceanergy.in</a>
                            <br>
                            <span class="fa-link">Website:</span>
                            <a href="http://www.oceanergy.in">http://www.oceanergy.in</a>
                        </p>
                        <p>C-1404, KAILASH BUSINESS PARK,
                            <br>HIRANADANI LINK ROAD,
                            <br>VIKHROLI (WEST), MAHARASHTRA - 400079
                        </p>
                    </div>
                    <!-- End Contact Details -->


                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- Footer Menu -->
        <div id="footer">
            <div class="container">
                <div class="row">
                    <div id="footermenu" class="col-md-8">

                    </div>
                    <div id="copyright" class="col-md-4">

                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Menu -->
        <!-- JS -->
        <script type="text/javascript" src="assets/js/jquery.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="assets/js/scripts.js"></script>
        <!-- Isotope - Portfolio Sorting -->
        <script type="text/javascript" src="assets/js/jquery.isotope.js" type="text/javascript"></script>
        <!-- Mobile Menu - Slicknav -->
        <script type="text/javascript" src="assets/js/jquery.slicknav.js" type="text/javascript"></script>
        <!-- Animate on Scroll-->
        <script type="text/javascript" src="assets/js/jquery.visible.js" charset="utf-8"></script>
        <!-- Sticky Div -->
        <script type="text/javascript" src="assets/js/jquery.sticky.js" charset="utf-8"></script>
        <!-- Slimbox2-->
        <script type="text/javascript" src="assets/js/slimbox2.js" charset="utf-8"></script>
        <!-- Modernizr -->
        <script src="assets/js/modernizr.custom.js" type="text/javascript"></script>
        <!-- End JS -->
</body>

</html>



<!-- === END FOOTER === -->+
