<!-- === BEGIN HEADER === -->


<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <!-- Title -->
    <title>ALL LEAVES</title>
    <!-- Meta -->
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- Favicon -->
    <link href="favicon.ico" rel="shortcut icon">
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/animate.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/nexus.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/custom.css" rel="stylesheet">
    <!-- Google Fonts-->
    <link href="http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=PT+Sans" type="text/css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Roboto:400,300" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="body-bg">
        <ul class="social-icons pull-right hidden-xs">

            <li class="social-twitter">
                <a href="#" target="_blank" title="Twitter"></a>
            </li>
            <li class="social-facebook">
                <a href="#" target="_blank" title="Facebook"></a>
            </li>
            <li class="social-googleplus">
                <a href="#" target="_blank" title="GooglePlus"></a>
            </li>
        </ul>
        <div id="pre-header" class="container" style="height: 40px">
            <!-- Spacing above header -->
        </div>
        <div id="header">
            <div class="container">
                <div class="row">
                    <!-- Logo -->
                    <div class="logo">

                        <a href="http://www.oceanergy.in/" title="">
                                <img src="assets/Oceanergy_Logo_PNG_HighRes.png" alt="Logo" width="69px" height="69px" align="left" style="margin-top:30px ;margin-right:10px"/>
                                
								 <img src="assets/Oceanergy_Name_PNG_HighRes.png" alt="Logo" width="169px" height="30px" align="left" style="margin-top:50px ;margin-right:120px" />
                            </a>
                    </div>
                    <!-- End Logo -->
                </div>
            </div>
        </div>
        <!---Top nav-->
        <div id="hornav" class="container no-padding">
            <div class="row">
                <div class="col-md-12 no-padding">
                    <div class="text-center visible-lg">
                        <ul id="hornavmenu" class="nav navbar-nav">
                            <li>
                                <a href="manager.php"  class="fa-home">Home</a>
                            </li>
                            <li>
                                <span class="fa-gears">Profile</span>
                                <ul>

                                    <li>
                                        <a href="emp.php">Employee</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="emp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="emp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="personal.php">Personal</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                           <li role="presentation"><a role="menuitem" tabindex="-1" href="personal.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="personal_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="academic.php">Academic</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="academic.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="academic_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a>Work Experience</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>

                                </ul>
                            </li>
                            <li>
                                <span class="fa fa-user">Manager
								</span>
                                <ul>
                                    <li>
                                        <a href="manager_empl.php">Employee Details</a>
                                    </li>
                                    
									
									
                                    <li>
                                        <a href="#">Announcements</a>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="announcement.php">Add Announcemnt</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="announcements.php">View Announcements</a></li>
                                        </ul>
                                    </li>

                                    <li>
                                        <a href="holidays.php"> View Holidays</a>
                         
                                    </li>

									
                                </ul>

                            </li>
                            <li>
                                <span class="fa-copy">Leaves </span>
                                <ul>
                                    <li>
                                        <a href="leave_man.php">Add Leaves</a>
                                    </li>
                                    <li>
                                        <a href="leave_dis.php"> ALL Leaves</a>
                                    </li>
                                    <li>
                                        <a href="leave_app_dis.php">Approve Leaves</a>
                                    </li>

                                </ul>
                            </li>
							
							 <li>
                                <span class="fa-copy">Projects</span>
                                <ul>
                                    <li>
                                        <a href="project_new.php">Add Project</a>
                                    </li>
                                    <li>
                                        <a href="projects.php">View Project</a>
                                    </li>
									 <li>
                                        <a href="#">Milestones</a>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="milestones.php">Add Milestone</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="miles_front.php">View Milestone</a></li>
                                        </ul>
                                    </li>
									<li>
                                        <a href="#">Task</a>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="task.php">Add Task</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="task_front.php">View Task</a></li>
                                        </ul>
                                    </li>
          
									<li>
                                        <a href="clients.php">View Clients</a>
                                    </li>
                                </ul>
                            </li>

							<li>
                                <span class="fa-copy">Salary</span>
                                <ul>
                                    
									<li>
                                        <a href="salary.php">Add Employee Salary</a>
                                    </li>
                                    
                                    <li>
                                        <a href="salary_front1.php">Monthly Salary</a>
                                    </li>
									
                                    <li>
                                        <a href="salary_front.php">Gross Salary</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> 
                                LOG OUT</a>

                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

		<!--- End Top nav-->
        <div id="post_header" class="container" style="height: 40px">
            <!-- Spacing below header -->
        </div>
        <div id="content-top-border" class="container">
        </div>
        <!-- === END HEADER === -->
        <!-- === BEGIN CONTENT === -->
        <div id="content">
            <div class="container background-white">
                <div class="container">
                    <div class="row margin-vert-40">
                        <div class="article">
                            <div class="container">
                                <form action="" method="POST">
                                     <div class="container text-center">
                                   
                                    <br>
                                    <?php
                                        require_once("connect.php");
                                        $sql=" SELECT * FROM leave_seek";
                                        $result = $conn->query($sql);
                                         
                                        if($result->num_rows > 0)
                                        {
                                            echo'<table class="table table-bordered" align="left">
                                                    <thead>
													<h1>Leave Approval</h1>
                                                      <tr>
                                                      <th>Employee ID</th>
                                                        <th>Leave Type</th>
                                                        <th>From Date</th>
                                                        <th>To Date</th>
                                                        <th>Reason</th>
                                                        <th>From</th>
                                                        <th>To</th>
														<th>Status</th>
														<th>Approve</th>
														<th>Reject</th>
                                                      </tr>
                                                    </thead>
                                                ';
                                                while($row = mysqli_fetch_assoc($result))
                                                {

                                                    echo '</tr>';
                                           $employee_id=$row['employee_id'];
                                                    echo'<tbody';
                                                    echo'<tr>';
                                                    echo'<td>'.$row["employee_id"].'</td>';
                                                    echo'<td>'.$row["leave_type"].'</td>';
                                                    echo'<td>'.$row["sdate"].'</td>';
                                                    echo'<td>'.$row["edate"].'</td>';
                                                    echo'<td>'.$row["reason"].'</td>';
                                                    echo'<td>'.$row["fmail"].'</td>';
                                                    echo'<td>'.$row["tmail"].'</td>';
													echo'<td>'.$row["status"].'</td>';
													 echo"<input type='hidden' name='employee_id' value='$employee_id'>";
													echo "<td><div style='text-align:right>
                                                    <a class='linnk'>
                                                    <input type='Submit' name='update' value='".$row['employee_id']."'></input>
                                                    </a>
                                                    </div></td>";
                                                    
                                                    echo "<td><div style='text-align:right>
                                                    <a class='linnk'>
                                                    <input type='Submit' name='update1' value='".$row['employee_id']."'></input>
                                                    </a>
                                                    </div></td>";
                                                    echo'</tr>';
                                              }  
                                            echo'</tbody>';
                                            echo'</table>';
                                            

                                      }
                                    else{
                                        echo "No results Found ";
                                    }
                                  ?>
                                </div>
                                </form>
                           
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php if(isset($_POST['update']))
										{ $employee_id=$_POST['update'];
									
											$qer="UPDATE leave_seek SET status='approved' WHERE employee_id='$employee_id'";
											if($conn->query($qer) === TRUE)
												echo"<a href='leave_dis.php'></a>";
											else
												echo"";
										}
										?>
										<?php if(isset($_POST['update1']))
										{ $employee_id=$_POST['update1'];
								
											$qer="UPDATE leave_seek SET status='rejected' WHERE employee_id='$employee_id'";
											if($conn->query($qer) === TRUE)
												echo"";
											else
												echo"";
										}
										?>

        <!-- === END CONTENT === -->
        <!-- === BEGIN FOOTER === -->
        <div id="content-bottom-border" class="container">
        </div>
        <div id="base">
            <div class="container padding-vert-30 margin-top-60">
                <div class="row" style="align:center">
                    <!-- Contact Details -->
                    <div class="col-md-4 margin-bottom-20">
                        <h3 class="margin-bottom-10">Contact Details</h3>
                        <p>
                            <span class="fa-phone">Telephone:</span>+91 7506067024 , 0222 5170789
                            <br>
                            <span class="fa-envelope">Email:</span>
                            <a href="mailto:admin@oceanergy.in">admin@oceanergy.in</a>
                            <br>
                            <span class="fa-link">Website:</span>
                            <a href="http://www.oceanergy.in">http://www.oceanergy.in</a>
                        </p>
                        <p>C-1404, KAILASH BUSINESS PARK,
                            <br>HIRANADANI LINK ROAD,
                            <br>VIKHROLI (WEST), MAHARASHTRA - 400079
                        </p>
                    </div>
                    <!-- End Contact Details -->


                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- Footer Menu -->
        <div id="footer">
            <div class="container">
                <div class="row">
                    <div id="footermenu" class="col-md-8">

                    </div>
                    <div id="copyright" class="col-md-4">

                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Menu -->
        <!-- JS -->
        <script type="text/javascript" src="assets/js/jquery.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="assets/js/scripts.js"></script>
        <!-- Isotope - Portfolio Sorting -->
        <script type="text/javascript" src="assets/js/jquery.isotope.js" type="text/javascript"></script>
        <!-- Mobile Menu - Slicknav -->
        <script type="text/javascript" src="assets/js/jquery.slicknav.js" type="text/javascript"></script>
        <!-- Animate on Scroll-->
        <script type="text/javascript" src="assets/js/jquery.visible.js" charset="utf-8"></script>
        <!-- Sticky Div -->
        <script type="text/javascript" src="assets/js/jquery.sticky.js" charset="utf-8"></script>
        <!-- Slimbox2-->
        <script type="text/javascript" src="assets/js/slimbox2.js" charset="utf-8"></script>
        <!-- Modernizr -->
        <script src="assets/js/modernizr.custom.js" type="text/javascript"></script>
        <!-- End JS -->
</body>

</html>



<!-- === END FOOTER === -->+
