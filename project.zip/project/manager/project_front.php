<!-- === BEGIN HEADER === -->
<?php 
require_once("session.php");
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html>


<?php include('connect.php'); ?>

<?php
error_reporting(0);
$res ='';
echo "1";
    echo '<head>
        <!-- Title -->
        <title>DETAILS</title>
        <!-- Meta -->
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<!-- Favicon -->
        <link href="favicon.ico" rel="shortcut icon">
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.css" rel="stylesheet">
        <!-- Template CSS -->
        <link rel="stylesheet" href="assets/css/animate.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/nexus.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/responsive.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/custom.css" rel="stylesheet">
        <!-- Google Fonts-->
        <link href="http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300" rel="stylesheet" type="text/css">
        <link href="http://fonts.googleapis.com/css?family=PT+Sans" type="text/css" rel="stylesheet">
        <link href="http://fonts.googleapis.com/css?family=Roboto:400,300" rel="stylesheet" type="text/css">
		
		
		<style>
		div.article
		{
			padding :15px;
		}
		
		
	table.datatable td  
	{
	   	border: 1px solid ;
	  border-collapse: separate;
      border-spacing: 2px;
     border-color: gray;
	 padding :15px;
	  
	}
	
	 table.button_update
	 {
		 float : right;
		 margin-right : 35%;
		 margin-top: 215px;
		 font-size : 16px;
		 color : black;
	 }
	
	
</style>
    </head>
	
	<body>
        <div id="body-bg">
            
            <div id="pre-header" class="container" style="height: 40px">
                <!-- Spacing above header -->
            </div>
            <div id="header">
                <div class="container">
                    <div class="row">
                        <!-- Logo -->
                        <div class="logo">
						
                            <a href="http://www.oceanergy.in/" title="">
                                <img src="assets/Oceanergy_Logo_PNG_HighRes.png" alt="Logo" width="69px" height="69px" align="left" style="margin-top:30px ;margin-right:10px""/>
								 <img src="assets/Oceanergy_Name_PNG_HighRes.png" alt="Logo" width="169px" height="30px" align="left" style="margin-top:50px ;margin-right:120px"/>
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>
                </div>
            </div>
             <!---Top nav-->
        <div id="hornav" class="container no-padding">
            <div class="row">
                <div class="col-md-12 no-padding">
                    <div class="text-center visible-lg">
                        <ul id="hornavmenu" class="nav navbar-nav">
                            <li>
                                <a href="admin.php" class="fa-home">Home</a>
                            </li>
                            <li>
                                <span class="fa-gears">Profile</span>
                                <ul>

                                    <li>
                                        <a href="emp.php">Employee</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="emp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="emp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="personal.php">Personal</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                           <li role="presentation"><a role="menuitem" tabindex="-1" href="personal.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="personal_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="academic.php">Academic</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                             <li role="presentation"><a role="menuitem" tabindex="-1" href="academic.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="academic_update.php">Update Details</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a>Work Experience</a>
										<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp.php">Add Details</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="workexp_update.php">Update Details</a></li>
                                        </ul>
                                    </li>

                                </ul>
                            </li>
                            <li>
                                <span class="fa fa-user">Manager
								</span>
                                <ul>
                                    <li>
                                        <a href="manager_empl.php">Employee Details</a>
                                    </li>
                                    
									
									
                                    <li>
                                        <a href="#">Announcements</a>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="announcement.php">Add Announcemnt</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="announcements.php">View Announcements</a></li>
                                        </ul>
                                    </li>

                                    <li>
                                        <a href="holidays.php"> View Holidays</a>
                         
                                    </li>

									
                                </ul>

                            </li>
                            <li>
                                <span class="fa-copy">Leaves </span>
                                <ul>
                                    <li>
                                        <a href="leave_man.php">Add Leaves</a>
                                    </li>
                                    <li>
                                        <a href="leave_dis.php"> ALL Leaves</a>
                                    </li>
                                    <li>
                                        <a href="leave_app_dis.php">Approve Leaves</a>
                                    </li>

                                </ul>
                            </li>
							
							 <li>
                                <span class="fa-copy">Projects</span>
                                <ul>
                                    <li>
                                        <a href="project_new.php">Add Project</a>
                                    </li>
                                    <li>
                                        <a href="projects.php">View Project</a>
                                    </li>
									 <li>
                                        <a href="#">Milestones</a>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="milestones.php">Add Milestone</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="miles_front.php">View Milestone</a></li>
                                        </ul>
                                    </li>
									<li>
                                        <a href="#">Task</a>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="task.php">Add Task</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="task_front.php">View Task</a></li>
                                        </ul>
                                    </li>
          
									<li>
                                        <a href="clients.php">View Clients</a>
                                    </li>
                                </ul>
                            </li>

							<li>
                                <span class="fa-copy">Salary</span>
                                <ul>
                                    
									<li>
                                        <a href="salary.php">Add Employee Salary</a>
                                    </li>
                                    
                                    <li>
                                        <a href="salary_front1.php">Monthly Salary</a>
                                    </li>
									
                                    <li>
                                        <a href="salary_front.php">Gross Salary</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> 
                                LOG OUT</a>

                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

		<!--- End Top nav-->
            <div id="post_header" class="container" style="height: 40px">
                <!-- Spacing below header -->
            </div>
            <div id="content-top-border" class="container">
            </div>
            <!-- === END HEADER === -->
            <!-- === BEGIN CONTENT === -->
            <div id="content">
                <div class="container background-white">
                    <div class="container">
                        <div class="row margin-vert-30">
                            <!-- Login Box -->
          
			<div class="article">
	<form  method="post" action="">
			<table  align="center">
			<tbody>
				<tr>
				<td align="left" colspan="2"><br>
				 <label for id="pid">*Project ID: </label><br>
				 <input type="text" id="pid" size="30" maxlength="100" name="project_id" required	name="project_id">		 
				 </td>
				</tr>
				</tbody>
				</table>
				
			<table  align="center" >
			<tbody>
				<tr>
					<td  colspan="1">
					<div style="text-align:right;margin :20px;font-size :16px;color :black">
					<a class="linnk" onclick="go-forward();">
					<input type="Submit" value="Submit">
					</a>
					</div>
					</td>
					
				</tr>	
			</tbody>
		</table>
		
	';
	
		

		$project_id =$_POST['project_id'];
	
	


		
		$query = "SELECT project_id FROM newproject"; //You don't need a ; like you do in SQL
		
		
$result = $conn->query($query);
$id=array();
$i=1;
 $result->data_seek(0);
while($data= $result->fetch_assoc())
{
	$id[$i++] = $data[project_id];
}

	$j=1;
	while($project_id!=$id[$j] && $j<=$i)
	{
		$j++;
	}
	if(!empty($project_id) && $j<=$i )
	{
		$result1="SELECT  *FROM newproject where project_id='".$project_id."'";
	$sql1 = $conn->query($result1)  ;
	$data = mysqli_fetch_array($sql1);
	
 
	 
	echo "
	 
	 
<div id='emp'>
<table align='left' class='datatable'>

<h3 style='text-align :left; font-weight : bold; margin-bottom:40px'>Project Details</h3>

<tr>
<td>Client Id</td>
    <td>".$data['client_id	']."</td>
</tr>

<tr>
<td>Company Name</td>
    <td>".$data['comname']."</td>
</tr>	

<tr>
<td>Contact</td>
    <td>".$data['tele_no']."</td>	
</tr>
	
	
<tr>	
<td>Title</td>
    <td>".$data['title']."</td>	
</tr>	

<tr>
<td>Description</td>
    <td>".$data['descp']."</td>
</tr>


<tr>
<td>Project Type</td>
    <td>".$data['proj_type']."</td>	
</tr>	

<tr>
<td>Start Date</td>
    <td>".$data['sdate']."</td>
</tr>


<tr>
<td>End Date</td>
    <td>".$data['edate']."</td>	
</tr>	

<tr>
<td>Expected End Date</td>
    <td>".$data['exdate']."</td>	
</tr>	

<tr>
<td>Status</td>
	<td>".$data['status']."</td>
</tr>

<tr>
<td>Manager Name</td>
    <td>".$data['man']."</td>	
</tr>	

<tr>
<td>Expected Revenue</td>
    <td>".$data['exrevenue']."</td>	
</tr>


</table>


		</div>
		";
	}
	else
	{
		echo "
		<h3 style='text-align : center' >**Please enter a valid Project ID.. </h3>";
	}
	
	 
	
	echo '
	
                            <!-- End Login Box -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- === END CONTENT === -->
            <!-- === BEGIN FOOTER === -->
            <div id="content-bottom-border" class="container">
            </div>
            <div id="base">
                <div class="container padding-vert-30 margin-top-60">
                    <div class="row" style="align:center">
                        <!-- Contact Details -->
                        <div class="col-md-4 margin-bottom-20">
                            <h3 class="margin-bottom-10">Contact Details</h3>
                            <p>
                                <span class="fa-phone">Telephone:</span>+91 7506067024 , 0222 5170789
                                <br>
                                <span class="fa-envelope">Email:</span>
                                <a href="mailto:admin@oceanergy.in">admin@oceanergy.in</a>
                                <br>
                                <span class="fa-link">Website:</span>
                                <a href="http://www.oceanergy.in">http://www.oceanergy.in</a>
                            </p>
                            <p>C-1404, KAILASH BUSINESS PARK,
							<br>HIRANADANI LINK ROAD,
							<br>VIKHROLI (WEST), MAHARASHTRA - 400079
                             </p>
                        </div>
                        <!-- End Contact Details -->

                        
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- Footer Menu -->
            <div id="footer">
                <div class="container">
                    <div class="row">
                        <div id="footermenu" class="col-md-8">
                           
                        </div>
                        <div id="copyright" class="col-md-4">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer Menu -->';
           
			echo '
			<!-- JS -->
            <script type="text/javascript" src="assets/js/jquery.min.js" type="text/javascript"></script>
            <script type="text/javascript" src="assets/js/bootstrap.min.js" type="text/javascript"></script>
            <script type="text/javascript" src="assets/js/scripts.js"></script>
            <!-- Isotope - Portfolio Sorting -->
            <script type="text/javascript" src="assets/js/jquery.isotope.js" type="text/javascript"></script>
            <!-- Mobile Menu - Slicknav -->
            <script type="text/javascript" src="assets/js/jquery.slicknav.js" type="text/javascript"></script>
            <!-- Animate on Scroll-->
            <script type="text/javascript" src="assets/js/jquery.visible.js" charset="utf-8"></script>
            <!-- Sticky Div -->
            <script type="text/javascript" src="assets/js/jquery.sticky.js" charset="utf-8"></script>
            <!-- Slimbox2-->
            <script type="text/javascript" src="assets/js/slimbox2.js" charset="utf-8"></script>
            <!-- Modernizr -->
            <script src="assets/js/modernizr.custom.js" type="text/javascript"></script>
            <!-- End JS -->
    </body>
</html>
<!-- === END FOOTER === -->';

?>
</html>