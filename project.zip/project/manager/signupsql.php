<?php

require_once("connect.php");
        

   if(isset($_POST['submit']))
   {

           
        $type=$_POST['type'];
         $emp_id=$_POST['emp_id'];
         $name=$_POST['name'];
         $email=$_POST['email'];
         $phone=$_POST['phone'];
         $username=$_POST['username'];
         $cpassword=$_POST['pswrepeat'];
         $password=$_POST['psw'];
     
        

        $sql=" INSERT INTO users(employee_id,name,email,phone,username,password,type)
        VALUES('$emp_id','$name','$email','$phone','$username','$password','$type')"; 
       
       
       
       if($password == $cpassword)        {
           if($conn->query($sql)== true)
       {
           echo"<script>alert('You have sign up successfully..')</script>";
           header('Refresh:0.1;URL=login.php');
       }
       else{
          echo "Please Enter valid credentials.";
         //  header('Refresh:0.1;URL=signup.php');
       }

           
       }else
       {
           echo "<script>alert('Password doesnt match..')</script>"; 
           header('Refresh:0.1;URL=signup.php');
           
       }
   }
    else{echo " ";}

$conn->close();
?>
