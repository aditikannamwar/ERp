<?php
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
 
$emp_id =$_POST['emp_id']; 
$name =$_POST['firstname'];
$gender =$_POST['gender'];
$address =$_POST['address'];
$email =$_POST['email'];
$tele_no =$_POST['tele_no'];
$dob =$_POST['dateb'];
$state=$_POST['state'];
$country=$_POST['country'];
$town=$_POST['town'];
$postcode=$_POST['postcode'];
echo "Postcode: ".$postcode;

$querry="UPDATE employee
SET name='".$name."',gender='".$gender."',dob='".$dob."',address='".$address."',postcode='".$postcode."',town='".$town."',state='".$state."',country='".$country."',tele_no='".$tele_no."',email='".$email."'
where emp_id='".$employee_id."'";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


