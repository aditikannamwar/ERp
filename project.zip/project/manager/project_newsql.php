<?php
  require_once('connect.php');
$project_id = $_POST['project_id'];   
$comname =$_POST['comname'];
$tele_no =$_POST['tele_no'];
$title =$_POST['title'];
$desc=$_POST['desc'];
$proj_type=$_POST['proj_type'];
$sdate=$_POST['sdate'];
$edate=$_POST['edate'];
$exdate=$_POST['exdate'];
$man=$_POST['man'];
$exrevenue=$_POST['exrevenue'];


$querry="INSERT INTO newproject(project_id,comname,tele_no,title,descp,proj_type,sdate,edate,exdate,man,exrevenue,status)
VALUES ('".$project_id."','".$comname."','".$tele_no."','".$title."','".$desc."','".$proj_type."','".$sdate."','".$edate."','".$exdate."','".$man."','".$exrevenue."','".$status."')";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:manager.php');
$conn->close();
?>


