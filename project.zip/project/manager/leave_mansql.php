<?php
require_once('connect.php');
   require_once('session.php');
$employee_id =$_SESSION['employee_id'];
$leave_type =$_POST['leave_type'];
$fdate =$_POST['fdate'];
$tdate=$_POST['tdate'];
$reason=$_POST['reason'];
$femail=$_SESSION['email'];
$temail=$_POST['temail'];
$day=$_POST['day'];


 /*
    ini_set( 'display_errors', 1 );
 
    error_reporting( E_ALL );
 
    $from = $femail;
 
    $to = $temail;
 
    $subject = "Checking PHP mail";
 
    $message = "".$reason;
 
    $headers = "From:" . $from;
 

   
    mail($to,$subject,$message,$headers);
 
    echo "The email message was sent.";

*/

	$querry="INSERT INTO leave_seek (employee_id,leave_type,sdate,edate,reason,fmail,tmail,day) 
VALUES('".$employee_id."','".$leave_type."','".$fdate."','".$tdate."','".$reason."','".$femail."','".$temail."','".$day."')";
echo $querry;

 
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
echo $leave_type;
echo $day;
$conn->close();
?>


