<?php
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
   
$eid =$_POST['employee_id'];
$sal =$_POST['sal_amt'];
$sdate =$_POST['sdate'];
$edate =$_POST['edate'];
$bonus =$_POST['bonus'];
$com =$_POST['com'];
$con =$_POST['con'];
$med =$_POST['med'];

$querry="INSERT INTO salary (eid,basic_sal,sdate,edate,bonus,comm,con,med) 
VALUES('".$eid."','".$sal."','".$sdate."','".$edate."','".$bonus."','".$com."','".$con."','".$med."')";
echo $querry;
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
$conn->close();
?>


