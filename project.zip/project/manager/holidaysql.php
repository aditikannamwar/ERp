<?php
  require_once('connect.php');
$date =$_POST['date'];
$day =$_POST['day'];
$hname =$_POST['hname'];
$rem=$_POST['rem'];


	$querry="INSERT INTO holiday (date,day,hname,remark) 
VALUES('".$date."','".$day."','".$hname."','".$rem."')";
echo $querry;

$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


