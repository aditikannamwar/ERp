<?php
require_once("session.php");
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
   
 
$name =$_POST['firstname'];
$gender =$_POST['gender'];
$address =$_POST['address'];
$email =$_POST['email'];
$tele_no =$_POST['tele_no'];
$dob =$_POST['dateb'];
$state=$_POST['state'];
$country=$_POST['country'];
$town=$_POST['town'];
$postcode=$_POST['postcode'];
echo "Postcode: ".$postcode;

$var = $_SESSION['employee_id'];
$search=$var;
$querry="INSERT INTO employee (employee_id,name,gender,dob,address,postcode,town,state,country,tele_no,email) 
VALUES('".$var."','".$name."','".$gender."','".$dob."','".$address."','".$postcode."','".$town."','".$state."','".$country."','".$tele_no."','".$email."	')";
echo $querry;
$success = $conn->query($querry);



if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}

header('location:personal.php');

$conn->close();
?>


