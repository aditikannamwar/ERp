<?php
error_reporting(0);
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }

$cname =$_POST['cname'];
$web =$_POST['web'];
$pemail =$_POST['pemail'];
$tele_no=$_POST['tele_no'];
$address =$_POST['address'];
$city=$_POST['city'];
$state=$_POST['state'];
$country=$_POST['country'];
$zip=$_POST['zip'];



$querry="INSERT INTO leave_type (cname,web,pemail,tele_no,address,state,country,zip) 
VALUES('".$cname."','".$web."','".$pemail."','".$tele_no."','".$address."','".$state."','".$country."','".$zip"')";
echo $querry;

$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
$conn->close();
?>


