<?php
   require_once('connect.php');
   
$aname =$_POST['aname'];
$desc =$_POST['desc'];
$stat =$_POST['stat'];



	$querry="INSERT INTO announcements(title,description,status) 
VALUES('".$aname."','".$desc."','".$stat."')";
echo $querry;

$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("Your Request Created Successfully!!")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


