<?php
require_once("session.php");
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }

$var = $_SESSION['employee_id'];
$search=$var;
$fname =$_POST['fname'];
$fthname =$_POST['fthname'];
$mthname =$_POST['mthname'];
$gender=$_POST['gender'];
$odob=$_POST['odob'];
$adob=$_POST['adob'];
$tele_no=$_POST['tele_no'];
$pemail=$_POST['pemail'];
$bg=$_POST['bg'];


$querry="UPDATE  personal  
SET fname='".$fname."',fthname='".$fthname."',mthname='".$mthname."',gender='".$gender."',odob='".$odob."',adob='".$adob."',tele_no='".$tele_no."',pemail='".$pemail."',bg='".$bg."'
WHERE emp_id='".$search."'";
echo $querry
$success = $conn->query($querry);
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}
header('location:admin.php');
$conn->close();
?>


