<?php
   $dbhost = 'localhost:3036';
   $dbuser = 'root';
   $dbpass = '';
   $conn = new mysqli('localhost','root','','erp');
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   else
   {
   echo 'Connected successfully';
   }
   
$employee_id =$_POST['employee_id'];
$status =$_POST['status'];
$leave_type =$_POST['leave_type'];
$day=$_POST['day'];


 /*
    ini_set( 'display_errors', 1 );
 
    error_reporting( E_ALL );
 
    $from = $femail;
 
    $to = $temail;
 
    $subject = "Checking PHP mail";
 
    $message = "".$reason;
 
    $headers = "From:" . $from;
 

   
    mail($to,$subject,$message,$headers);
 
    echo "The email message was sent.";

*/

	$querry="UPDATE leave_seek SET status= '".$status."'  where employee_id='".$employee_id."'";
echo $querry;
 
 
$success = $conn->query($querry);

if($status='approved')
 {
	 if($leave_type='casual')
	 {
		 $querry1="UPDATE leave_approved SET casual_leave =casual_leave + days and days='".$day."' where employee_id='".$employee_id."'";
	echo $querry1;
	$success1 = $conn->query($querry1);
	 }
	 elseif($leave_type='priviledge')
	 {
		 $querry2="UPDATE leave_approved SET priviledge_leave=priviledge_leave+days and days='".$day."' where employee_id='".$employee_id."'";
	echo $querry2;
	$success2 = $conn->query($querry2);
	 }
	elseif($leave_type='sick')
	 {
		 $querry3="UPDATE leave_approved SET sick_leave= sick_leave+days and  days='".$day."' where employee_id='".$employee_id."'";
	echo $querry3;
	$success3 = $conn->query($querry3);
	 }
 }

	 
if($success)
{
print '<script type="text/javascript">';
print 'alert("The data is inserted...")';
print '</script>';
}

//header('location:admin.php');
$conn->close();
?>


