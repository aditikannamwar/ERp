<?php
                                        require_once("connect.php");
                                        $sql=" SELECT * FROM leave_seek";
                                        $result = $conn->query($sql);
                                         
                                        if($result->num_rows > 0)
                                        {
                                            echo'<table class="table table-bordered" align="left">
                                                    <thead>
													<h1>Leave Approval</h1>
                                                      <tr>
                                                      <th>Employee ID</th>
                                                        <th>Leave Type</th>
                                                        <th>From Date</th>
                                                        <th>To Date</th>
                                                        <th>Reason</th>
                                                        <th>From</th>
                                                        <th>To</th>
														<th>Update</th>
                                                      </tr>
                                                    </thead>
                                                ';
                                                while($row = mysqli_fetch_assoc($result))
                                                {

                                                    echo '</tr>';
                                           
                                                    echo'<tbody';
                                                    echo'<tr>';
                                                    echo'<td>'.$row["employee_id"].'</td>';
                                                    echo'<td>'.$row["leave_type"].'</td>';
                                                    echo'<td>'.$row["sdate"].'</td>';
                                                    echo'<td>'.$row["edate"].'</td>';
                                                    echo'<td>'.$row["reason"].'</td>';
                                                    echo'<td>'.$row["fmail"].'</td>';
                                                    echo'<td>'.$row["tmail"].'</td>';
													echo "<td><div style='text-align:right>
                                                    <a class='linnk' onclick='go-forward();'>
                                                    <input type='Submit' value='Update'>
                                                    </a>
                                                    </div></td>";
                                                    
                                                   
                                                    echo'</tr>';
                                              }  
                                            echo'</tbody>';
                                            echo'</table>';
                                            

                                      }
                                    else{
                                        echo "No results Found ";
                                    }
                                  ?>